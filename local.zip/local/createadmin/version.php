<?php

defined('MOODLE_INTERNAL') || die;

$plugin->version = 2022041907;
$plugin->requires = 2022041200;
$plugin->cron = 0;
$plugin->component = 'local_createadmin';
$plugin->maturity = MATURITY_RC;
$plugin->release = '2.4-rc';
